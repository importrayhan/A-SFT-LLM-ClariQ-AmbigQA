import gc

import numpy as np
import torch
import torch.nn as nn

from llm_attacks.minimal_gcg.opt_utils5 import token_gradients, sample_control, get_logits, target_loss
from llm_attacks.minimal_gcg.opt_utils5 import load_model_and_tokenizer, get_filtered_cands
from llm_attacks.minimal_gcg.string_utils import SuffixManager, load_conversation_template
from llm_attacks import get_nonascii_toks

import os
import gc
import psutil
import torch
import json
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"

def print_system_memory():
    """Print comprehensive system memory status"""
    print("\n" + "="*60)
    print("SYSTEM MEMORY STATUS")
    print("="*60)
    
    # CPU Memory
    cpu_memory = psutil.virtual_memory()
    print(f"🖥️  CPU Memory:")
    print(f"   Total:     {cpu_memory.total / 1024**3:.1f} GB")
    print(f"   Used:      {cpu_memory.used / 1024**3:.1f} GB ({cpu_memory.percent:.1f}%)")
    print(f"   Available: {cpu_memory.available / 1024**3:.1f} GB")
    
    # GPU Memory
    if torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            gpu_memory = torch.cuda.get_device_properties(i)
            allocated = torch.cuda.memory_allocated(i) / 1024**3
            reserved = torch.cuda.memory_reserved(i) / 1024**3
            total = gpu_memory.total_memory / 1024**3
            
            print(f"🔥 GPU {i} ({gpu_memory.name}):")
            print(f"   Total:     {total:.1f} GB")
            print(f"   Allocated: {allocated:.1f} GB")
            print(f"   Reserved:  {reserved:.1f} GB")
            print(f"   Free:      {total - reserved:.1f} GB")
    
    print("="*60 + "\n")
#from livelossplot import PlotLosses # pip install livelossplot

# Set the random seed for NumPy
np.random.seed(20)

# Set the random seed for PyTorch
torch.manual_seed(20)

# If you are using CUDA (i.e., a GPU), also set the seed for it
torch.cuda.manual_seed_all(20)

model_path = "/mnt/scratch/users/40645696/qwen2.5-72b-clariq/Qwen/hub/Qwen/Qwen2.5-72B-Instruct"

#----------------------------Class for Qwen-----------------------------------------
# qwen_template.py
from typing import List, Tuple, Optional

class QwenConversationTemplate:
    """
    Minimal conversation template compatible with SuffixManager.
    Customize formatting to Qwen-style prompts.
    """

    def __init__(
        self,
        name: str = "qwen",
        system: str = "You are a helpful assistant.",
        roles: Tuple[str, str] = ("[user]", "[assistant]"),
        sep: str = "\n",
        sep2: str = "\n\n",
    ):
        self.name = name
        self.system = system or ""
        self.roles = tuple(roles)
        self.sep = sep
        self.sep2 = sep2
        # messages is list of tuples (role_label, text_or_None)
        self.messages: List[Tuple[str, Optional[str]]] = []

    def append_message(self, role: str, text: Optional[str]):
        """
        Append a message. role should be one of self.roles entries.
        text can be None (used by SuffixManager to create partial prompts).
        """
        if role not in self.roles:
            # allow passing role index as int
            raise ValueError(f"Unknown role: {role}. Allowed: {self.roles}")
        self.messages.append((role, text))

    def update_last_message(self, text: Optional[str]):
        """Replace the last message's text (keep its role)."""
        if not self.messages:
            raise RuntimeError("No last message to update")
        role = self.messages[-1][0]
        self.messages[-1] = (role, text)

    def clear_messages(self):
        self.messages = []

    def get_prompt(self) -> str:
        """
        Build the prompt string. Format:
        [system]\n
        [role0] text0\n[role1] text1\n...
        Use sep/sep2 between messages as required.
        """
        parts: List[str] = []
        if self.system:
            parts.append(self.system.strip())

        for (role, text) in self.messages:
            # role label and content; if text is None, put role only (for placeholder)
            if text is None:
                parts.append(f"{role}")
            else:
                parts.append(f"{role} {text}")

        # Join with sep2 if available; you can customize per Qwen conventions
        return self.sep2.join(parts)


conv_template = QwenConversationTemplate(
    name="qwen",
    system="You are a search engine performance predictor. A user is looking for something which is often not clearly understood. Your task is to decide if a search request is oscure. Imagine that you will enter a giant library to find out the requested answer. Given the user request, do you think you have a clearly specified search query to find an information? Now think of a four level indicator ranging 1 green, 2 yellow, 3 orange, 4 red. Green means search request is not obscure, yellow means somewhat obscure, orange means you will struggle to find what user wants as the topic is generic, red means extreme ambiguous query which can be multiple topics. You task is not to provide answer, Only Give one digit value ranging from 1 to 4 to predict the query’s retrieval performance. Again, DO NOT ATTEMPT TO ANSWER!",
    roles=("[user]", "[assistant]"),
    sep="\n",
    sep2="\n\n",
)

print(conv_template)
#----------------------------------------------------------------------------------
num_steps = 32
user_prompt = "Where exactly is that tower?"
adv_string_init = "! ! ! ! ! ! ! ! ! !"
target = "1"
#device = 'auto'
batch_size = 1
topk = 2
device= "cuda"
allow_non_ascii = False # you can set this to True to use unicode tokens

test_prefixes = ["3",  "4",]
print_system_memory()
model, tokenizer = load_model_and_tokenizer(model_path, tokenizer_path = model_path,
                       low_cpu_mem_usage=True, 
                       device=device,
                       use_cache=False,
                       torch_dtype=torch.bfloat16,
                       #n_devices=2,
                       device_map="auto")
print_system_memory()

suffix_manager = SuffixManager(tokenizer=tokenizer, 
              conv_template=conv_template, 
              instruction=user_prompt, 
              target=target, 
              adv_string=adv_string_init)

def generate(model, tokenizer, input_ids, assistant_role_slice, gen_config=None):
    if gen_config is None:
        gen_config = model.generation_config
        gen_config.max_new_tokens = 1

    if gen_config.max_new_tokens > 50:
        print('WARNING: max_new_tokens > 32 may cause testing to slow down.')
        
    input_ids = input_ids[:assistant_role_slice.stop].to(model.device).unsqueeze(0)
    attn_masks = torch.ones_like(input_ids).to(model.device)
    output_ids = model.generate(input_ids, 
                                attention_mask=attn_masks, 
                                generation_config=gen_config,
                                pad_token_id=tokenizer.pad_token_id)[0]

    return output_ids[assistant_role_slice.stop:]

def check_for_attack_success(model, tokenizer, input_ids, assistant_role_slice, test_prefixes, gen_config=None):
    gen_str = tokenizer.decode(generate(model, 
                                        tokenizer, 
                                        input_ids, 
                                        assistant_role_slice, 
                                        gen_config=gen_config)).strip()
    jailbroken = not any([prefix in gen_str for prefix in test_prefixes])
    return jailbroken
#plotlosses = PlotLosses()

not_allowed_tokens = None if allow_non_ascii else get_nonascii_toks(tokenizer) 
adv_suffix = adv_string_init


for i in range(num_steps):
    
    # Step 1. Encode user prompt (behavior + adv suffix) as tokens and return token ids.
    input_ids = suffix_manager.get_input_ids(adv_string=adv_suffix)
    input_ids = input_ids.to(device)
    
    # Step 2. Compute Coordinate Gradient
    coordinate_grad = token_gradients(model, 
                    input_ids,
                    suffix_manager._control_slice, 
                    suffix_manager._target_slice, 
                    suffix_manager._loss_slice)
    
    # Step 3. Sample a batch of new tokens based on the coordinate gradient.
    # Notice that we only need the one that minimizes the loss.
    with torch.no_grad():
        
        # Step 3.1 Slice the input to locate the adversarial suffix.
        adv_suffix_tokens = input_ids[suffix_manager._control_slice].to(device)
        
        # Step 3.2 Randomly sample a batch of replacements.
        new_adv_suffix_toks = sample_control(adv_suffix_tokens, 
                       coordinate_grad, 
                       batch_size, 
                       topk=topk, 
                       temp=1, 
                       not_allowed_tokens=not_allowed_tokens)
        
        # Step 3.3 This step ensures all adversarial candidates have the same number of tokens. 
        # This step is necessary because tokenizers are not invertible
        # so Encode(Decode(tokens)) may produce a different tokenization.
        # We ensure the number of token remains to prevent the memory keeps growing and run into OOM.
        new_adv_suffix = get_filtered_cands(tokenizer, 
                                            new_adv_suffix_toks, 
                                            filter_cand=True, 
                                            curr_control=adv_suffix)
        
        # Step 3.4 Compute loss on these candidates and take the argmin.
        logits, ids = get_logits(model=model, 
                                 tokenizer=tokenizer,
                                 input_ids=input_ids,
                                 control_slice=suffix_manager._control_slice, 
                                 test_controls=new_adv_suffix, 
                                 return_ids=True,
                                 batch_size=1) # decrease this number if you run into OOM.

        losses = target_loss(logits, ids, suffix_manager._target_slice)

        best_new_adv_suffix_id = losses.argmin()
        best_new_adv_suffix = new_adv_suffix[best_new_adv_suffix_id]

        current_loss = losses[best_new_adv_suffix_id]

        # Update the running adv_suffix with the best candidate
        adv_suffix = best_new_adv_suffix
        is_success = check_for_attack_success(model, 
                                 tokenizer,
                                 suffix_manager.get_input_ids(adv_string=adv_suffix).to(device), 
                                 suffix_manager._assistant_role_slice, 
                                 test_prefixes)
        

    # Create a dynamic plot for the loss.
    #plotlosses.update({'Loss': current_loss.detach().cpu().numpy()})
    #plotlosses.send() 
    print(new_adv_suffix)
    print(f"\nPassed:{is_success}\nCurrent Suffix:{best_new_adv_suffix}", end='\r')
    
    # Notice that for the purpose of demo we stop immediately if we pass the checker but you are free to
    # comment this to keep the optimization running for longer (to get a lower loss). 
    if is_success:
        break
    
    # (Optional) Clean up the cache.
    del coordinate_grad, adv_suffix_tokens ; gc.collect()
    torch.cuda.empty_cache()
    
