
import gc
import psutil
import numpy as np
import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer

from llm_attacks import get_embedding_matrix, get_embeddings
def print_memory_usage(step_name=""):
    """Print both GPU and CPU memory usage"""
    if torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            gpu_memory = torch.cuda.memory_allocated(i) / 1024**3
            gpu_cached = torch.cuda.memory_reserved(i) / 1024**3
            print(f"{step_name} - GPU {i}: {gpu_memory:.2f}GB allocated, {gpu_cached:.2f}GB cached")
    
    cpu_memory = psutil.virtual_memory()
    print(f"{step_name} - CPU: {cpu_memory.used/1024**3:.2f}GB used, {cpu_memory.available/1024**3:.2f}GB available")
    print("-" * 50)

def clear_gpu_cache():
    """Aggressive GPU cache clearing"""
    if torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            with torch.cuda.device(i):
                torch.cuda.empty_cache()
        gc.collect()

def token_gradients_approximated(model, input_ids, input_slice, target_slice, loss_slice, 
                                grad_sample_ratio=0.3, use_finite_diff=True, epsilon=1e-3):
    """
    Memory-efficient gradient approximation using sampling and finite differences
    """
    print_memory_usage("token_gradients_approximated - start")
    
    embed_weights = get_embedding_matrix(model)
    vocab_size = embed_weights.shape[0]
    control_length = input_slice.stop - input_slice.start
    
    if use_finite_diff:
        # Use finite differences - much more memory efficient
        print("Using finite differences for gradient approximation")
        return finite_difference_gradients(model, input_ids, input_slice, target_slice, loss_slice, epsilon)
    
    # Sample-based gradient approximation
    sample_size = max(1, int(control_length * grad_sample_ratio))
    print(f"Using sample-based gradients: {sample_size}/{control_length} positions")
    
    # Initialize gradient tensor on CPU
    grad_approx = torch.zeros(control_length, vocab_size, dtype=torch.bfloat16, device='cpu')
    
    # Sample random positions for gradient computation
    sampled_positions = torch.randperm(control_length)[:sample_size]
    
    for pos_idx, pos in enumerate(sampled_positions):
        print(f"Computing gradient for position {pos_idx+1}/{sample_size}")
        
        # Compute gradient for single position
        pos_grad = compute_single_position_gradient(
            model, input_ids, input_slice, target_slice, loss_slice, pos
        )
        
        if pos_grad is not None:
            grad_approx[pos] = pos_grad.cpu()
        
        clear_gpu_cache()
        
        if (pos_idx + 1) % 5 == 0:
            print_memory_usage(f"Processed {pos_idx+1}/{sample_size} positions")
    
    # Interpolate for unsampled positions
    for i in range(control_length):
        if i not in sampled_positions:
            # Find nearest sampled positions
            distances = torch.abs(sampled_positions.float() - i)
            nearest_idx = distances.argmin()
            nearest_pos = sampled_positions[nearest_idx]
            grad_approx[i] = grad_approx[nearest_pos]
    
    # Normalize
    grad_norms = grad_approx.norm(dim=-1, keepdim=True)
    grad_norms[grad_norms == 0] = 1  # Avoid division by zero
    grad_approx = grad_approx / grad_norms
    
    print_memory_usage("token_gradients_approximated - end")
    return grad_approx

def finite_difference_gradients(model, input_ids, input_slice, target_slice, loss_slice, epsilon=1e-3):
    """
    Compute gradients using finite differences - very memory efficient
    """
    print_memory_usage("finite_difference_gradients - start")
    
    embed_weights = get_embedding_matrix(model)
    vocab_size = embed_weights.shape[0]
    control_length = input_slice.stop - input_slice.start
    
    # Get baseline loss
    baseline_loss = compute_loss_for_ids(model, input_ids, target_slice, loss_slice)
    print(f"Baseline loss: {baseline_loss:.4f}")
    
    # Initialize gradient on CPU
    grad_fd = torch.zeros(control_length, vocab_size, dtype=torch.bfloat16, device='cpu')
    
    # Sample a subset of vocabulary for efficiency
    vocab_sample_size = min(vocab_size, 40)  # Sample 1000 tokens max
    sampled_vocab = torch.randperm(vocab_size)[:vocab_sample_size]
    
    print(f"Using finite differences: {vocab_sample_size}/{vocab_size} vocab tokens")
    
    for pos in range(control_length):
        if pos % 10 == 0:
            print(f"FD gradient for position {pos+1}/{control_length}")
            print_memory_usage(f"FD position {pos+1}")
        
        original_token = input_ids[input_slice.start + pos].item()
        
        # Compute finite differences for sampled vocabulary
        for i, token_id in enumerate(sampled_vocab):
            if token_id == original_token:
                continue
                
            # Perturb input
            perturbed_ids = input_ids.clone()
            perturbed_ids[input_slice.start + pos] = token_id
            
            # Compute perturbed loss
            perturbed_loss = compute_loss_for_ids(model, perturbed_ids, target_slice, loss_slice)
            
            # Finite difference approximation
            grad_fd[pos, token_id] = (perturbed_loss - baseline_loss) / epsilon
            
            del perturbed_ids
            
            if i % 100 == 0:
                clear_gpu_cache()
    
    # Fill in unsampled tokens with interpolation
    unsampled_mask = torch.ones(vocab_size, dtype=torch.bool)
    unsampled_mask[sampled_vocab] = False
    unsampled_indices = torch.where(unsampled_mask)[0]
    
    for pos in range(control_length):
        for token_id in unsampled_indices:
            # Use nearest sampled token value
            distances = torch.abs(sampled_vocab.float() - token_id)
            nearest_sampled = sampled_vocab[distances.argmin()]
            grad_fd[pos, token_id] = grad_fd[pos, nearest_sampled]
    
    print_memory_usage("finite_difference_gradients - end")
    return grad_fd

def compute_single_position_gradient(model, input_ids, input_slice, target_slice, loss_slice, position):
    """
    Compute gradient for a single position using minimal memory
    """
    try:
        embed_weights = get_embedding_matrix(model)
        vocab_size = embed_weights.shape[0]
        
        # Create minimal one-hot for single position
        one_hot = torch.zeros(1, vocab_size, device=model.device, dtype=embed_weights.dtype)
        token_id = input_ids[input_slice.start + position]
        one_hot[0, token_id] = 1.0
        one_hot.requires_grad_(True)
        
        # Get embeddings efficiently
        with torch.no_grad():
            embeds = get_embeddings(model, input_ids.unsqueeze(0))
        
        # Replace only the specific position
        modified_embeds = embeds.clone()
        position_embed = (one_hot @ embed_weights)
        modified_embeds[0, input_slice.start + position] = position_embed
        
        # Forward pass with minimal memory
        with torch.cuda.amp.autocast():  # Use mixed precision
            logits = model(inputs_embeds=modified_embeds).logits
            targets = input_ids[target_slice].to(model.device)
            loss = nn.CrossEntropyLoss()(logits[0, loss_slice, :], targets)
        
        # Backward pass
        loss.backward()
        grad = one_hot.grad.clone()
        
        # Cleanup
        del one_hot, embeds, modified_embeds, logits, targets, loss, position_embed
        clear_gpu_cache()
        
        return grad.squeeze(0)  # Remove batch dimension
        
    except Exception as e:
        print(f"Error computing gradient for position {position}: {e}")
        clear_gpu_cache()
        return None

def compute_loss_for_ids(model, input_ids, target_slice, loss_slice):
    """
    Compute loss for given input_ids efficiently
    """
    try:
        with torch.no_grad():
            input_ids_gpu = input_ids.to(model.device)
            with torch.cuda.amp.autocast():
                logits = model(input_ids=input_ids_gpu.unsqueeze(0)).logits
                targets = input_ids_gpu[target_slice]
                loss = nn.CrossEntropyLoss()(logits[0, loss_slice, :], targets)
            
            loss_val = loss.item()
            del input_ids_gpu, logits, targets, loss
            clear_gpu_cache()
            return loss_val
            
    except Exception as e:
        print(f"Error computing loss: {e}")
        clear_gpu_cache()
        return float('inf')

def token_gradients_checkpoint(model, input_ids, input_slice, target_slice, loss_slice, checkpoint_segments=4):
    """
    Gradient computation with gradient checkpointing to save memory
    """
    print_memory_usage("token_gradients_checkpoint - start")
    
    try:
        embed_weights = get_embedding_matrix(model)
        control_length = input_slice.stop - input_slice.start
        
        # Create one_hot on CPU, smaller chunks
        one_hot = torch.zeros(
            control_length,
            embed_weights.shape[0],
            dtype=torch.float16,  # Use half precision
            device='cpu'
        )
        
        input_slice_tokens = input_ids[input_slice].cpu()
        one_hot.scatter_(1, input_slice_tokens.unsqueeze(1), 1.0)
        
        # Process in smaller chunks
        chunk_size = max(1, control_length // checkpoint_segments)
        gradients = []
        
        for i in range(0, control_length, chunk_size):
            end_idx = min(i + chunk_size, control_length)
            chunk_one_hot = one_hot[i:end_idx].to(model.device)
            chunk_one_hot.requires_grad_(True)
            
            print(f"Processing gradient chunk {i//chunk_size + 1}/{(control_length + chunk_size - 1)//chunk_size}")
            
            # Compute embeddings for chunk
            chunk_embeds = (chunk_one_hot @ embed_weights)
            
            # Get full embeddings
            with torch.no_grad():
                full_embeds = get_embeddings(model, input_ids.unsqueeze(0))
            
            # Replace chunk
            modified_embeds = full_embeds.clone()
            modified_embeds[0, input_slice.start + i:input_slice.start + end_idx] = chunk_embeds
            
            # Use gradient checkpointing for forward pass
            def create_forward_fn(embeds):
                def forward_fn():
                    return model(inputs_embeds=embeds).logits
                return forward_fn
            
            logits = torch.utils.checkpoint.checkpoint(create_forward_fn(modified_embeds))
            
            targets = input_ids[target_slice].to(model.device)
            loss = nn.CrossEntropyLoss()(logits[0, loss_slice, :], targets)
            
            loss.backward()
            chunk_grad = chunk_one_hot.grad.clone().cpu()
            gradients.append(chunk_grad)
            
            # Cleanup
            del chunk_one_hot, chunk_embeds, full_embeds, modified_embeds, logits, targets, loss
            clear_gpu_cache()
            
            print_memory_usage(f"Chunk {i//chunk_size + 1} completed")
        
        # Combine gradients
        grad = torch.cat(gradients, dim=0)
        grad = grad / grad.norm(dim=-1, keepdim=True)
        
        print_memory_usage("token_gradients_checkpoint - end")
        return grad
        
    except Exception as e:
        print(f"Checkpoint gradient computation failed: {e}")
        clear_gpu_cache()
        # Fallback to finite differences
        return finite_difference_gradients(model, input_ids, input_slice, target_slice, loss_slice)

# Updated main function with multiple fallback strategies
def token_gradients(model, input_ids, input_slice, target_slice, loss_slice):
    """
    Multi-strategy gradient computation with fallbacks
    """
    strategies = [
        ("finite_difference", lambda: finite_difference_gradients(model, input_ids, input_slice, target_slice, loss_slice)),
        ("approximated_30%", lambda: token_gradients_approximated(model, input_ids, input_slice, target_slice, loss_slice, grad_sample_ratio=0.3)),
        ("approximated_10%", lambda: token_gradients_approximated(model, input_ids, input_slice, target_slice, loss_slice, grad_sample_ratio=0.1)),
        ("checkpoint", lambda: token_gradients_checkpoint(model, input_ids, input_slice, target_slice, loss_slice))
    ]
    
    for strategy_name, strategy_fn in strategies:
        try:
            print(f"Trying gradient computation strategy: {strategy_name}")
            result = strategy_fn()
            print(f"Successfully computed gradients using {strategy_name}")
            return result
        except Exception as e:
            print(f"Strategy {strategy_name} failed: {e}")
            clear_gpu_cache()
            continue
    
    raise RuntimeError("All gradient computation strategies failed")

# Keep the rest of the functions the same as in the previous version
def sample_control(control_toks, grad, batch_size, topk=16, temp=1, not_allowed_tokens=None):
    """CPU-optimized sampling - keep everything on CPU"""
    print_memory_usage("sample_control - start")
    
    # Ensure everything is on CPU
    grad_cpu = grad.cpu() if grad.device.type == 'cuda' else grad
    control_toks_cpu = control_toks.cpu() if control_toks.device.type == 'cuda' else control_toks
    
    if not_allowed_tokens is not None:
        not_allowed_tokens_cpu = not_allowed_tokens.cpu() if not_allowed_tokens.device.type == 'cuda' else not_allowed_tokens
        grad_cpu[:, not_allowed_tokens_cpu] = np.infty

    # All operations on CPU
    top_indices = (-grad_cpu).topk(topk, dim=1).indices
    original_control_toks = control_toks_cpu.repeat(batch_size, 1)
    
    new_token_pos = torch.arange(
        0, len(control_toks_cpu), 
        len(control_toks_cpu) / batch_size,
        device='cpu'
    ).type(torch.int64)
    
    new_token_val = torch.gather(
        top_indices[new_token_pos], 1, 
        torch.randint(0, topk, (batch_size, 1), device='cpu')
    )
    
    new_control_toks = original_control_toks.scatter_(1, new_token_pos.unsqueeze(-1), new_token_val)
    
    print_memory_usage("sample_control - end")
    return new_control_toks

def get_filtered_cands(tokenizer, control_cand, filter_cand=True, curr_control=None):
    """No changes needed - already CPU efficient"""
    cands, count = [], 0
    # Move to CPU if needed
    control_cand_cpu = control_cand.cpu() if control_cand.device.type == 'cuda' else control_cand
    
    for i in range(control_cand_cpu.shape[0]):
        decoded_str = tokenizer.decode(control_cand_cpu[i], skip_special_tokens=True)
        if filter_cand:
            if decoded_str != curr_control and len(tokenizer(decoded_str, add_special_tokens=False).input_ids) == len(control_cand_cpu[i]):
                cands.append(decoded_str)
            else:
                count += 1
        else:
            cands.append(decoded_str)

    if filter_cand:
        cands = cands + [cands[-1]] * (len(control_cand_cpu) - len(cands))
    return cands

def get_logits(*, model, tokenizer, input_ids, control_slice, test_controls=None, return_ids=False, batch_size=512):
    """Memory-optimized logits computation"""
    print_memory_usage("get_logits - start")
    
    if isinstance(test_controls[0], str):
        max_len = control_slice.stop - control_slice.start
        # Process on CPU first
        test_ids = [
            torch.tensor(tokenizer(control, add_special_tokens=False).input_ids[:max_len], device='cpu')
            for control in test_controls
        ]
        
        # Find pad token
        input_ids_cpu = input_ids.cpu()
        pad_tok = 0
        while pad_tok in input_ids_cpu or any([pad_tok in ids for ids in test_ids]):
            pad_tok += 1
            
        # Create padded tensor on CPU
        nested_ids = torch.nested.nested_tensor(test_ids)
        test_ids = torch.nested.to_padded_tensor(nested_ids, pad_tok, (len(test_ids), max_len))
    else:
        raise ValueError(f"test_controls must be a list of strings, got {type(test_controls)}")

    if not(test_ids[0].shape[0] == control_slice.stop - control_slice.start):
        raise ValueError((
            f"test_controls must have shape "
            f"(n, {control_slice.stop - control_slice.start}), " 
            f"got {test_ids.shape}"
        ))

    # Create locations and ids on CPU
    locs = torch.arange(control_slice.start, control_slice.stop).repeat(test_ids.shape[0], 1)
    ids = torch.scatter(
        input_ids_cpu.unsqueeze(0).repeat(test_ids.shape[0], 1),
        1,
        locs,
        test_ids
    )
    
    # Create attention mask on CPU
    if pad_tok >= 0:
        attn_mask = (ids != pad_tok).type(ids.dtype)
    else:
        attn_mask = None

    print_memory_usage("get_logits - tensors prepared on CPU")
    
    # Clean up CPU tensors
    del locs, test_ids, input_ids_cpu
    gc.collect()

    if return_ids:
        logits = forward(model=model, input_ids=ids, attention_mask=attn_mask, batch_size=batch_size)
        return logits, ids.cpu()  # Return ids on CPU
    else:
        logits = forward(model=model, input_ids=ids, attention_mask=attn_mask, batch_size=batch_size)
        del ids
        gc.collect()
        return logits

def forward(*, model, input_ids, attention_mask, batch_size=1):
    """Memory-optimized forward pass - move data to GPU only when needed"""
    print_memory_usage("forward - start")
    
    logits_list = []
    
    for i in range(0, input_ids.shape[0], batch_size):
        print(f"Processing batch {i//batch_size + 1}/{(input_ids.shape[0] + batch_size - 1)//batch_size}")
        
        # Get batch on CPU first
        batch_input_ids_cpu = input_ids[i:i+batch_size]
        batch_attention_mask_cpu = attention_mask[i:i+batch_size] if attention_mask is not None else None
        
        # Move to GPU only for forward pass
        batch_input_ids_gpu = batch_input_ids_cpu.to(model.device)
        batch_attention_mask_gpu = batch_attention_mask_cpu.to(model.device) if batch_attention_mask_cpu is not None else None
        
        print_memory_usage(f"forward - batch {i//batch_size + 1} moved to GPU")
        
        # Forward pass
        with torch.no_grad():  # Save memory during inference
            batch_logits = model(input_ids=batch_input_ids_gpu, attention_mask=batch_attention_mask_gpu).logits
        
        # Immediately move result to CPU and clear GPU
        batch_logits_cpu = batch_logits.cpu()
        logits_list.append(batch_logits_cpu)
        
        del batch_input_ids_gpu, batch_attention_mask_gpu, batch_logits
        clear_gpu_cache()
        
        print_memory_usage(f"forward - batch {i//batch_size + 1} completed")

    # Concatenate on CPU
    result = torch.cat(logits_list, dim=0)
    del logits_list
    gc.collect()
    
    print_memory_usage("forward - end")
    return result

def target_loss(logits, ids, target_slice):
    """CPU-optimized loss computation"""
    print_memory_usage("target_loss - start")
    
    # Ensure everything is on CPU
    logits_cpu = logits.cpu() if logits.device.type == 'cuda' else logits
    ids_cpu = ids.cpu() if ids.device.type == 'cuda' else ids
    
    crit = nn.CrossEntropyLoss(reduction='none')
    loss_slice = slice(target_slice.start-1, target_slice.stop-1)
    loss = crit(logits_cpu[:,loss_slice,:].transpose(1,2), ids_cpu[:,target_slice])
    
    result = loss.mean(dim=-1)
    
    print_memory_usage("target_loss - end")
    return result

def load_model_and_tokenizer(model_path, tokenizer_path= None, device="cuda", **kwargs):
    model = AutoModelForCausalLM.from_pretrained(
            model_path,
            #torch_dtype=torch.bfloat16,
            trust_remote_code=False,
            **kwargs
        ).eval()
    
    tokenizer_path = model_path if tokenizer_path is None else tokenizer_path
    
    tokenizer = AutoTokenizer.from_pretrained(
        tokenizer_path,
        trust_remote_code=True,
        local_files_only=True,
        use_fast=False
    )
    if "qwen2" in model_path.lower():
        tokenizer.pad_token = tokenizer.eos_token   # Qwen2 needs this
        tokenizer.padding_side = "left"
    if 'oasst-sft-6-llama-30b' in tokenizer_path:
        tokenizer.bos_token_id = 1
        tokenizer.unk_token_id = 0
    if 'guanaco' in tokenizer_path:
        tokenizer.eos_token_id = 2
        tokenizer.unk_token_id = 0
    if 'llama-2' in tokenizer_path:
        tokenizer.pad_token = tokenizer.unk_token
        tokenizer.padding_side = 'left'
    if 'falcon' in tokenizer_path:
        tokenizer.padding_side = 'left'
    if not tokenizer.pad_token:
        tokenizer.pad_token = tokenizer.eos_token
    
    return model, tokenizer
